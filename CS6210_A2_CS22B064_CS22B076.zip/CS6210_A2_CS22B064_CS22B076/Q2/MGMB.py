import numpy as np
import random
import sys
import argparse

total_packets = int(1e4)

# Generalized service time generator
def generate_generalized_service_times(total_packets, service_time_distribution):

    total_probability = sum(service_time_distribution.values())
    if abs(total_probability - 1.0) > 1e-4:
        print("Probabilities in the file do not sum up to 1.")
        sys.exit(1)
    
    generalized_service_times = []
    for _ in range(total_packets):
        p = random.random()
        cumulative_probability = 0
        for time, prob in service_time_distribution.items():
            cumulative_probability += prob
            if p <= cumulative_probability:
                generalized_service_times.append(time)
                break
    
    return generalized_service_times

# Hyperexponential service time generator
def generate_hyperexponential_service_times(service_rates, probability):

    if abs(sum(probability) - 1.0) > 1e-4:
        print("Probabilities do not sum up to 1.")
        sys.exit(1)
    
    hyperexponential_service_times = []
    for _ in range(total_packets):
        p = random.random()
        if p <= probability[0]:
            hyperexponential_service_times.append(np.random.exponential(scale=1/service_rates[0]))
        elif p <= probability[0] + probability[1]:
            hyperexponential_service_times.append(np.random.exponential(scale=1/service_rates[1]))
        else:
            hyperexponential_service_times.append(np.random.exponential(scale=1/service_rates[2]))
    
    return hyperexponential_service_times

# Generalized queue simulator
def generalized_queue_simulation(arrival_rate, total_servers, buffer_size, service_time_distribution):

    total_packets = int(1e4)
    served_packets = 0
    dropped_packets = 0
    total_packets_in_system = []
    delays = []
    queue = []
    server_busy_until = [0] * total_servers
    inter_arrival_times = np.random.exponential(scale=1/arrival_rate, size=total_packets)
    service_times = generate_generalized_service_times(total_packets, service_time_distribution)

    for i in range(total_packets):
        arrival_time = sum(inter_arrival_times[:i+1])
        current_time = arrival_time
        queue = [departure for departure in queue if departure > arrival_time]
        total_packets_in_system.append(len(queue))
        min_index = np.argmin(server_busy_until)

        if len(queue) < buffer_size or buffer_size == -1:

            served_packets += 1
            if server_busy_until[min_index] <= arrival_time:
                exit_time = arrival_time + service_times[i]
                server_busy_until[min_index] = exit_time
                delays.append(service_times[i])
            else:
                exit_time = server_busy_until[min_index] + service_times[i]
                server_busy_until[min_index] += service_times[i]
                delays.append(exit_time - arrival_time)
            
            queue.append(exit_time)
        else:
            dropped_packets += 1
    
    avg_pkt_delay = np.mean(delays) if delays else 0
    var_pkt_delay = np.var(delays) if delays else 0
    avg_num_pkts_in_system = np.mean(total_packets_in_system) if total_packets_in_system else 0
    blocking_prob = dropped_packets / total_packets

    return {
        "avg_pkt_delay": avg_pkt_delay,
        "variance_pkt_delay": var_pkt_delay,
        "avg_num_pkts_in_system": avg_num_pkts_in_system,
        "blocking_prob": blocking_prob,
    }


# Hyperexponential queue simulator
def hyperexponential_queue_simulation(arrival_rate, total_servers, buffer_size, service_rates, probability):

    total_packets = int(1e4)
    served_packets = 0
    dropped_packets = 0
    total_packets_in_system = []
    delays = []
    queue = []
    server_busy_until = [0] * total_servers
    inter_arrival_times = np.random.exponential(scale=1/arrival_rate, size=total_packets)
    service_times = generate_hyperexponential_service_times(service_rates, probability)

    for i in range(total_packets):
        arrival_time = sum(inter_arrival_times[:i+1])
        current_time = arrival_time
        queue = [departure for departure in queue if departure > arrival_time]
        total_packets_in_system.append(len(queue))
        min_index = np.argmin(server_busy_until)

        if len(queue) < buffer_size or buffer_size == -1:

            served_packets += 1
            if server_busy_until[min_index] > arrival_time:
                exit_time = server_busy_until[min_index] + service_times[i]
                server_busy_until[min_index] += service_times[i]
                delays.append(exit_time - arrival_time)
            else:
                exit_time = arrival_time + service_times[i]
                server_busy_until[min_index] = exit_time
                delays.append(service_times[i])
            
            queue.append(exit_time)
        else:
            dropped_packets += 1
    
    avg_pkt_delay = np.mean(delays) if delays else 0
    var_pkt_delay = np.var(delays) if delays else 0
    avg_num_pkts_in_system = np.mean(total_packets_in_system) if total_packets_in_system else 0
    blocking_prob = dropped_packets / total_packets

    return {
        "avg_pkt_delay": avg_pkt_delay,
        "variance_pkt_delay": var_pkt_delay,
        "avg_num_pkts_in_system": avg_num_pkts_in_system,
        "blocking_prob": blocking_prob,
    }

# Unified simulation router
def queue_simulation(arrival_rate, total_servers, buffer_size, service, service_rates=None, probability=None, service_time_distribution=None):

    if service == 'G':
        return generalized_queue_simulation(arrival_rate, total_servers, buffer_size, service_time_distribution)
    elif service == 'H':
        return hyperexponential_queue_simulation(arrival_rate, total_servers, buffer_size, service_rates, probability)
    else:
        print(f"Unsupported service type: {service}")
        sys.exit(1)

# Result printer
def print_results(arrival_rate, total_servers, buffer_size, metrics):
    print(f"B: {buffer_size}; L: {arrival_rate:.3f}; m: {total_servers}; R: {metrics['avg_pkt_delay']:.3f}; N: {metrics['avg_num_pkts_in_system']:.3f}")

# File reader for generalized distribution
def read_service_time_file(file_name):
    service_time_distribution = {}
    try:
        with open(file_name, 'r') as file:
            total_entries = int(file.readline().strip())
            for _ in range(total_entries):
                line = file.readline().strip().split()
                time = float(line[0])
                prob = float(line[1])
                service_time_distribution[time] = prob

    except FileNotFoundError:
        print(f"File {file_name} not found.")
        sys.exit(1)
    return service_time_distribution

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='M/G/m/B Queue Simulator')
    parser.add_argument('arrival_rate', type=float, help='Arrival rate (lambda)')
    parser.add_argument('servers', type=int, help='Number of servers (m)')
    parser.add_argument('service_type', choices=['H', 'G'], help='Service type (H: hyper-exponential, G: generalized)')
    
    args, unknown = parser.parse_known_args()

    if args.service_type == 'G':
        parser.add_argument('service_time_file', type=str)
        parser.add_argument('buffer_size', type=int)
        args = parser.parse_args()
        
        service_time_distribution = read_service_time_file(args.service_time_file)
        result = queue_simulation(args.arrival_rate, args.servers, args.buffer_size, 'G', 
                          service_time_distribution=service_time_distribution)

    elif args.service_type == 'H':
        for i in range(3):
            parser.add_argument(f'servicerate{i+1}', type=float)
        for i in range(3):
            parser.add_argument(f'p{i+1}', type=float)
        parser.add_argument('buffer_size', type=int)
        args = parser.parse_args()
        service_rates = [getattr(args, f'servicerate{i+1}') for i in range(3)]
        probability = [getattr(args, f'p{i+1}') for i in range(3)]

        result = queue_simulation(args.arrival_rate, args.servers, args.buffer_size, 'H', 
                          service_rates=service_rates, probability=probability)
        
    
    print_results(args.arrival_rate, args.servers, args.buffer_size, result)