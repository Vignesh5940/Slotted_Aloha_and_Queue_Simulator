import matplotlib.pyplot as plt
import numpy as np

# Sample data structure (modify with your actual data)
data = {
    'R': {
        1: {
            10: {'lambda': [0.4, 0.6, 0.8], 'value': [2.27, 3.15, 4.78]},
            -1: {'lambda': [0.4, 0.6, 0.8], 'value': [2.23, 3.37, 7.66]}
        },
        # Add m=2 data here
    },
    'N': {
        1: {
            10: {'lambda': [0.4, 0.6, 0.8], 'value': [0.94, 1.90, 3.61]},
            -1: {'lambda': [0.4, 0.6, 0.8], 'value': [0.92, 1.98, 6.06]}
            # Add more B values for m=1 here
        },
        # Add m=2 data here
    }
}

# Create plots for each metric
for metric in ['R', 'N']:
    plt.figure(figsize=(12, 6))
    
    # Create subplots for each m value
    for m_idx, m in enumerate(data[metric].keys(), 1):
        plt.subplot(1, 2, m_idx)
        
        # Plot each buffer size (B)
        for b in data[metric][m]:
            plt.plot(data[metric][m][b]['lambda'], 
                    data[metric][m][b]['value'],
                    marker='o',
                    label=f'B={b}')
            
        plt.title(f'{metric} vs λ (m={m})')
        plt.xlabel('Arrival Rate (λ)')
        plt.ylabel('E[{}]'.format(metric))
        plt.grid(True)
        plt.legend()
    
    plt.tight_layout()
    plt.show()