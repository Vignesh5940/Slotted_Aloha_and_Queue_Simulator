import matplotlib.pyplot as plt
import numpy as np
import subprocess
import os

# Experiment parameters
Ls = [0.001, 0.005, 0.01, 0.05, 0.1, 0.2, 0.3, 0.5, 0.6]
Ms = [16, 32]
Bs = [0.3, 0.5]

# Helper function to run shell commands
def run_command(cmd):
    result = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode != 0:
        print(f"[ERROR] {cmd}\n{result.stderr.decode()}")
        return None
    return result.stdout.decode()

# Prepare plot folder
output_dir = "plots"
os.makedirs(output_dir, exist_ok=True)

for M in Ms:
    fig_syt, ax_syt = plt.subplots(figsize=(8, 5))
    fig_delay, ax_delay = plt.subplots(figsize=(8, 5))

    for B in Bs:
        syt_sim, delay_sim = [], []
        syt_model, delay_model = [], []

        for L in Ls:
            # Run simulation
            sim_out = run_command(f"python3 sades.py {M} {L} {B}")
            if sim_out:
                parts = sim_out.strip().split(";")
                syt_sim.append(float(parts[3].split("=")[1]))
                delay_sim.append(float(parts[4].split("=")[1]))
            else:
                syt_sim.append(np.nan)
                delay_sim.append(np.nan)

            # Run DTMC model
            model_out = run_command(f"python3 sadtmc.py {M} {L} {B}")
            if model_out:
                parts = model_out.strip().split(";")
                syt_model.append(float(parts[3].split("=")[1]))
                delay_model.append(float(parts[4].split("=")[1]))
            else:
                syt_model.append(np.nan)
                delay_model.append(np.nan)

        # Plot throughput
        ax_syt.plot(Ls, syt_model, label=f"DTMC B={B}", linestyle='-', marker=None)
        ax_syt.plot(Ls, syt_sim, label=f"Sim B={B}", linestyle='--', marker='o')

        # Plot delay
        ax_delay.plot(Ls, delay_model, label=f"DTMC B={B}", linestyle='-', marker=None)
        ax_delay.plot(Ls, delay_sim, label=f"Sim B={B}", linestyle='--', marker='s')

    # Final touches for throughput
    ax_syt.set_title(f"System Throughput vs L (M={M})")
    ax_syt.set_xlabel("L (Total Arrival Rate)")
    ax_syt.set_ylabel("System Throughput")
    ax_syt.grid(True)
    ax_syt.legend()
    fig_syt.tight_layout()
    fig_syt.savefig(f"{output_dir}/system_throughput_M{M}.png")
    plt.close(fig_syt)

    # Final touches for delay
    ax_delay.set_title(f"Average Delay vs L (M={M})")
    ax_delay.set_xlabel("L (Total Arrival Rate)")
    ax_delay.set_ylabel("Average Delay (slots)")
    ax_delay.grid(True)
    ax_delay.legend()
    fig_delay.tight_layout()
    fig_delay.savefig(f"{output_dir}/delay_M{M}.png")
    plt.close(fig_delay)

print("✅ All 4 comparative plots saved in the 'plots/' directory.")