import simpy
import sys
import numpy as np
from random import random

class Node:
    def __init__(self, env, node_id, arrival_prob, B):
        self.env = env
        self.id = node_id
        self.buffer = []  # Stores (arrival_time, state) tuples (max 2)
        self.arrival_prob = arrival_prob  # Bernoulli arrival probability
        self.B = B  # Retransmission probability for backlogged packets
        self.transmissions = 0
        self.successes = 0
        self.packet_delays = []
        self.process = env.process(self.packet_arrival())

    def packet_arrival(self):
        # Slot-aligned Bernoulli arrivals
        while True:
            yield self.env.timeout(1)  # Align to slot boundaries
            if len(self.buffer) < 2 and random() < self.arrival_prob:
                self.buffer.append((self.env.now, 'new'))  # Track state

def slot_processor(env, nodes, stats, slot_time):
    while True:
        transmissions = []
        for node in nodes:
            if len(node.buffer) > 0:
                arrival_time, state = node.buffer[0]
                if state == 'new':
                    transmissions.append(node)  # Transmit new packets immediately
                    node.transmissions += 1
                elif random() < node.B:  # Retry backlogged packets with B
                    transmissions.append(node)
                    node.transmissions += 1

        # Resolve collisions
        if len(transmissions) == 1:
            node = transmissions[0]
            node.successes += 1
            arrival_time, _ = node.buffer.pop(0)
            delay = env.now - arrival_time
            node.packet_delays.append(delay)
            stats['successes'] += 1
        else:
            # Mark collided packets as backlogged
            for node in transmissions:
                if len(node.buffer) > 0:
                    node.buffer[0] = (node.buffer[0][0], 'backlogged')

        yield env.timeout(slot_time)

def slotted_aloha_des(M, L, B, sim_time=100000):
    env = simpy.Environment()
    slot_time = 1.0
    stats = {'successes': 0}

    arrival_prob_per_node = L / M  # Bernoulli arrival rate per node
    nodes = [Node(env, i, arrival_prob_per_node, B) for i in range(M)]
    env.process(slot_processor(env, nodes, stats, slot_time))
    env.run(until=sim_time)

    total_success = stats['successes']
    per_node_throughput = total_success / sim_time / M
    system_throughput = total_success / sim_time

    all_delays = []
    for node in nodes:
        all_delays.extend(node.packet_delays)
    avg_delay = np.mean(all_delays) if all_delays else 0.0

    return per_node_throughput, system_throughput, avg_delay

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python sades.py M L B")
        sys.exit(1)
    
    M = int(sys.argv[1])
    L = float(sys.argv[2])
    B = float(sys.argv[3])
    
    pnt, syt, d = slotted_aloha_des(M, L, B)
    print(f"M={M}; L={L:.5f}; PNT={pnt:.5f}; SYT={syt:.5f}; D={d:.5f}")