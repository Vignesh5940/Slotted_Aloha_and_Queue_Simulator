import numpy as np
import sys

def construct_P(beta1, alpha, Ps):
    P = np.zeros((5, 5))  # States: S0, S1, S2, S3, S4

    # S0: Idle (no packets)
    P[0, 0] = 1 - beta1    # No arrival → stay in S0
    P[0, 1] = beta1        # Arrival → S1 (transmit HOL packet)

    # S1: Transmitting HOL packet (buffer empty)
    P[1, 0] = Ps * (1 - beta1)       # Success + no arrival → S0
    P[1, 1] = Ps * beta1             # Success + arrival → S1
    P[1, 3] = (1 - Ps) * (1 - beta1) # Failure + no arrival → S3 (backoff)
    P[1, 4] = (1 - Ps) * beta1       # Failure + arrival → S4 (backoff, buffer full)

    # S2: Transmitting HOL packet (buffer has 1 packet)
    # New arrivals are LOST; transitions depend only on transmission outcome
    P[2, 1] = Ps       # Success → Transmit next packet (S1)
    P[2, 4] = 1 - Ps   # Failure → Backoff with both packets (S4)

    # S3: Backoff with 1 packet
    P[3, 1] = alpha * (1 - beta1)    # Attempt retransmission + no arrival → S1
    P[3, 2] = alpha * beta1          # Attempt retransmission + arrival → S2 (buffer full)
    P[3, 3] = (1 - alpha) * (1 - beta1) # No attempt + no arrival → S3
    P[3, 4] = (1 - alpha) * beta1    # No attempt + arrival → S4

    # S4: Backoff with 2 packets
    P[4, 2] = alpha    # Attempt retransmission → S2 (buffer full)
    P[4, 4] = 1 - alpha  # No attempt → S4

    return P

def solve_steady_state(P, max_iter=1000, tol=1e-10):
    v = np.ones(5) / 5  # Initial guess (uniform distribution)
    for _ in range(max_iter):
        v_new = v @ P
        if np.linalg.norm(v_new - v) < tol:
            break
        v = v_new
    return v / np.sum(v)  # Ensure normalization

def slotted_aloha_dtmc(M, L, B, max_iter=1000, tol=1e-10):
    lambda_per_node = L / M
    beta1 = 1 - np.exp(-lambda_per_node)  # Poisson arrival probability

    # Iterate to find Ps and steady-state probabilities
    v1, v2 = 0.1, 0.1  # Initial guesses for v1 (S1) and v2 (S2)
    for _ in range(max_iter):
        # Corrected success probability calculation
        Ps = (1 - (v1 + v2)) ** (M - 1)  # No other nodes transmit
        P = construct_P(beta1, B, Ps)
        v = solve_steady_state(P)
        new_v1, new_v2 = v[1], v[2]
        if abs(new_v1 - v1) + abs(new_v2 - v2) < tol:
            break
        v1, v2 = new_v1, new_v2

    # Performance metrics
    per_node_throughput = Ps * (v1 + v2)
    system_throughput = M * per_node_throughput

    # Average delay (Little's Law)
    E_n = 0*v[0] + 1*v[1] + 2*v[2] + 1*v[3] + 2*v[4]
    avg_delay = E_n / per_node_throughput

    return per_node_throughput, system_throughput, avg_delay

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python sadtmc.py M L B")
        sys.exit(1)
    
    M = int(sys.argv[1])
    L = float(sys.argv[2])
    B = float(sys.argv[3])
    
    pnt, syt, d = slotted_aloha_dtmc(M, L, B)
    print(f"M={M}; L={L:.5f}; PNT={pnt:.5f}; SYT={syt:.5f}; D={d:.5f}")